
import React from 'react';

import TaskApp from './Component/TaskApp';
function App() {
  
  return (
    <div className="App">
      <TaskApp/>
    </div>
  );
}

export default App;
