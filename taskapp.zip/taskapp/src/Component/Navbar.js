// Navbar.js
import React from 'react';
import './Navbar.css'; // Assuming you will style it using a separate CSS file

const Navbar = ({ onAddTask }) => {
  return (
    <nav className="navbar">
      <div className="navbar-logo">
        <h1>Task</h1>
      </div>
      <div className="navbar-button">
        <button onClick={onAddTask}>Add New Task</button> {/* This button now opens the modal */}
      </div>
    </nav>
  );
};

export default Navbar;
