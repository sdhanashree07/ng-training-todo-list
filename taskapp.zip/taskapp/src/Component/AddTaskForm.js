// AddTaskForm.js
import React, { useState, useEffect } from 'react';
import './AddTaskForm.css'; // Import the CSS file for styling

const AddTaskForm = ({ onAddTask, taskToEdit, isEditing }) => {
  const [assignedTo, setAssignedTo] = useState('');
  const [status, setStatus] = useState('Pending');
  const [dueDate, setDueDate] = useState('');
  const [priority, setPriority] = useState('Low');
  const [comment, setComment] = useState('');

  // Pre-fill form fields when editing a task
  useEffect(() => {
    if (isEditing && taskToEdit) {
      setAssignedTo(taskToEdit.assignedTo);
      setStatus(taskToEdit.status);
      setDueDate(taskToEdit.dueDate);
      setPriority(taskToEdit.priority);
      setComment(taskToEdit.comment);
    }
  }, [isEditing, taskToEdit]);

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    const updatedTask = {
      id: taskToEdit ? taskToEdit.id : Date.now(),
      assignedTo,
      status,
      dueDate,
      priority,
      comment,
    };
    onAddTask(updatedTask); // Call the add/edit task function

    // Reset form fields
    setAssignedTo('');
    setStatus('Pending');
    setDueDate('');
    setPriority('Low');
    setComment('');
  };

  return (
    <form onSubmit={handleSubmit} className="task-form">
      <div className="form-row">
        <div className="form-group">
          <label>Assigned To:</label>
          <input type="text" value={assignedTo} onChange={(e) => setAssignedTo(e.target.value)} required />
        </div>
        <div className="form-group">
          <label>Status:</label>
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="Pending">Pending</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
          </select>
        </div>
      </div>

      <div className="form-row">
        <div className="form-group">
          <label>Due Date:</label>
          <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} required />
        </div>
        <div className="form-group">
          <label>Priority:</label>
          <select value={priority} onChange={(e) => setPriority(e.target.value)}>
            <option value="Low">Low</option>
            <option value="Normal">Normal</option>
            <option value="High">High</option>
          </select>
        </div>
      </div>

      <div className="form-row">
        <div className="form-group">
          <label>Comment:</label>
          <input type="text" value={comment} onChange={(e) => setComment(e.target.value)} />
        </div>
      </div>

      <button type="submit" className="submit-button">{isEditing ? 'Update Task' : 'Add Task'}</button>
    </form>
  );
};

export default AddTaskForm;
