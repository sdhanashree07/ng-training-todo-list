// TaskApp.js
import React, { useState } from 'react';
import TaskList from './TaskList';
import AddTaskForm from './AddTaskForm';
import ConfirmationModal from './ConfirmationModal';
import Navbar from './Navbar'; // Updated to use Navbar
import Modal from './Modal'; // Assuming you have a Modal component
import './TaskList.css';


const TaskApp = () => {
  const [tasks, setTasks] = useState([]); // Task list state
  const [isModalOpen, setModalOpen] = useState(false); // Modal state
  const [isEditing, setIsEditing] = useState(false); // Edit mode state
  const [taskToEdit, setTaskToEdit] = useState(null); // Task to edit state
  const [isDeleteModalOpen, setDeleteModalOpen] = useState(false); // Delete confirmation modal state
  const [taskToDelete, setTaskToDelete] = useState(null); // Task to delete state

  // Add or update task handler
  const handleAddTask = (newTask) => {
    if (isEditing) {
      // Update the existing task
      setTasks(tasks.map((task) => (task.id === taskToEdit.id ? newTask : task)));
      setIsEditing(false);
      setTaskToEdit(null);
    } else {
      // Add new task with a unique ID
      setTasks([...tasks, { id: Date.now(), ...newTask }]);
    }
    setModalOpen(false); // Close the modal after adding or editing
  };

  // Delete task handler
  const handleDeleteTask = () => {
    console.log('Task to delete:', taskToDelete); // Debugging
    // Check if taskToDelete has been set correctly
    if (taskToDelete) {
      // Remove task by ID
      setTasks(tasks.filter((task) => task.id !== taskToDelete.id));
      console.log('Task deleted:', taskToDelete.id);
    }

    // Close the confirmation modal after deletion
    setDeleteModalOpen(false);
    setTaskToDelete(null); // Clear the task to delete state
  };
  // Open the delete confirmation modal
  const confirmDeleteTask = (task) => {
    console.log('Confirm delete task:', task); // Debugging
    setTaskToDelete(task); // Set the task to delete
    setDeleteModalOpen(true); // Open the confirmation modal
  };

  // Edit task handler
  const handleEditTask = (task) => {
    setTaskToEdit(task); // Set the task to edit
    setIsEditing(true); // Enable edit mode
    setModalOpen(true); // Open the modal for editing
  };

  return (
    <div>
      <Navbar onAddTask={() => setModalOpen(true)} /> {/* Pass the function to open the modal */}
      <Modal isOpen={isModalOpen} onClose={() => { setModalOpen(false); setIsEditing(false); setTaskToEdit(null); }}>
        <AddTaskForm onAddTask={handleAddTask} taskToEdit={taskToEdit} isEditing={isEditing} />
      </Modal>
      <TaskList tasks={tasks} onDeleteTask={confirmDeleteTask} onEditTask={handleEditTask} />

       {/* Confirmation Modal */}
       <ConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => setDeleteModalOpen(false)} // Close the confirmation modal when Cancel is clicked
        onConfirm={handleDeleteTask} // Delete the task if Confirm is clicked
      />
    </div>
  );
};

export default TaskApp;
